import { useState, useEffect } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { 
  Home, Users, ShoppingCart, Package, Settings, 
  ChevronDown, ChevronRight, Menu as MenuIcon,
  BarChart, FileText, Shield, Database, X
} from 'lucide-react'
import menuApi from '../menu/menuApi'

// 권한 상수 정의
export const ROLES = {
  GUEST: 'GUEST',
  USER: 'USER',
  MANAGER: 'MANAGER',
  ADMIN: 'ADMIN'
}

// 아이콘 매핑
const iconMap = {
  'DashboardIcon': Home,
  'PeopleIcon': Users,
  'UsersIcon': Users,
  'ShoppingCartIcon': ShoppingCart,
  'PackageIcon': Package,
  'ReceiptIcon': FileText,
  'SettingsIcon': Settings,
  'BarChartIcon': BarChart,
  'ShieldIcon': Shield,
  'DatabaseIcon': Database,
  'MenuIcon': MenuIcon,
  'ListIcon': FileText,
  'SecurityIcon': Shield,
  'ArticleIcon': FileText,
  'ComputerIcon': Settings,
  'TuneIcon': Settings
}

const Sidebar = ({ isOpen, onClose }) => {
  const [menus, setMenus] = useState([])
  const [expandedMenus, setExpandedMenus] = useState({})
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  // 기본 메뉴 (폴백)
  const getDefaultMenus = () => [
    {
      id: 'dashboard',
      name: '대시보드',
      path: '/dashboard',
      icon: 'DashboardIcon',
      children: []
    },
    {
      id: 'admin',
      name: '관리자 패널',
      path: '/admin',
      icon: 'ShieldIcon',
      children: []
    },
    // {
    //   id: 'users',
    //   name: '사용자 관리',
    //   path: '/admin/users',
    //   icon: 'UsersIcon',
    //   children: []
    // },
    // {
    //   id: 'menus',
    //   name: '메뉴 관리',
    //   path: '/admin/menus',
    //   icon: 'MenuIcon',
    //   children: []
    // },

    {
      id: 'models',
      name: 'Models',
      path: null,
      icon: 'Brain',
      roles: [ROLES.USER, ROLES.MANAGER, ROLES.ADMIN],
      isDropdown: true,
      order: 4,  // ← 순서 변경 (3 → 4)
      subItems: [
        {
          id: 'isolation-forest',
          name: 'Isolation Forest',
          subtitle: '격리 숲',
          description: '이상치는 정상보다 쉽게 격리된다',
          application: '비정상적인 센서 조합 즉시 감지',
          strengths: '실시간 이상 탐지, 빠른 속도',
          weaknesses: '시계열 패턴 무시',
          path: '/models/isolation-forest',
          roles: [ROLES.USER, ROLES.MANAGER, ROLES.ADMIN]
        },
        {
          id: 'lstm',
          name: 'LSTM',
          subtitle: '장단기 메모리',
          description: '게이트 메커니즘으로 장기 기억 유지',
          application: '30분~1시간 전 패턴 학습',
          strengths: '복잡한 시계열 의존성 포착',
          weaknesses: '학습 시간 길고 데이터 많이 필요',
          path: '/models/lstm',
          roles: [ROLES.USER, ROLES.MANAGER, ROLES.ADMIN]
        },
        {
          id: 'gru',
          name: 'GRU',
          subtitle: '게이트 순환 유닛',
          description: 'LSTM 간소화 버전 (2개 게이트)',
          application: '5~15분 단기 급변 감지',
          strengths: 'LSTM보다 빠르고 효율적',
          weaknesses: '매우 긴 시퀀스에서 성능 저하',
          path: '/models/gru',
          roles: [ROLES.USER, ROLES.MANAGER, ROLES.ADMIN]
        },
        {
          id: 'random-forest',
          name: 'Random Forest',
          subtitle: '랜덤 포레스트',
          description: '여러 결정트리의 투표/평균',
          application: '센서 특징의 통계적 분석',
          strengths: '특징 중요도 제공, 과적합 방지',
          weaknesses: '시간적 순서 고려 못함',
          path: '/models/random-forest',
          roles: [ROLES.USER, ROLES.MANAGER, ROLES.ADMIN]
        },
        {
          id: 'xgboost',
          name: 'XGBoost',
          subtitle: '극한 그래디언트 부스팅',
          description: '이전 오류를 학습하며 순차적 개선',
          application: '복잡한 센서 간 상호작용 학습',
          strengths: '최고 수준 정확도, 빠른 속도',
          weaknesses: '하이퍼파라미터 튜닝 복잡',
          path: '/models/xgboost',
          roles: [ROLES.USER, ROLES.MANAGER, ROLES.ADMIN]
        }
      ]
    },

    {
      id: 'products',
      name: '상품 관리',
      path: '/products',
      icon: 'PackageIcon',
      children: []
    },
    {
      id: 'orders',
      name: '주문 관리',
      path: '/orders',
      icon: 'ShoppingCartIcon',
      children: []
    },
    {
      id: 'boards',
      name: '게시판',
      path: '/boards',
      icon: 'FileText',
      children: []
    }
  ]

  // 메뉴 데이터 로드
  useEffect(() => {
    console.log('🔧 [Sidebar] 컴포넌트 마운트됨')
    console.log('🔧 [Sidebar] 기본 메뉴 사용 중...')
    
    // 임시: 기본 메뉴만 사용 (API 호출 비활성화)
    setMenus(getDefaultMenus())
    setLoading(false)
    
    // API 호출 활성화하려면 fetchMenus() 호출
    // fetchMenus()
  }, [])

  const fetchMenus = async () => {
    try {
      setLoading(true)
      console.log('📡 [Sidebar] 메뉴 API 호출 시작...')
      
      // menuApi import 필요
      // import menuApi from '../menu/menuApi'
      // const data = await menuApi.getMenuTree()
      
      const data = getDefaultMenus()
      console.log('✅ [Sidebar] 메뉴 데이터:', data)
      
      setMenus(data)
    } catch (error) {
      console.error('❌ [Sidebar] 메뉴 로드 실패:', error)
      setMenus(getDefaultMenus())
    } finally {
      setLoading(false)
    }
  }

  const toggleMenu = (menuId) => {
    setExpandedMenus(prev => ({
      ...prev,
      [menuId]: !prev[menuId]
    }))
  }

  const handleMenuClick = (menu) => {
    console.log('🖱️ [Sidebar] 메뉴 클릭:', menu.name)
    
    if (menu.children && menu.children.length > 0) {
      toggleMenu(menu.id)
    } else if (menu.path) {
      console.log('🔗 [Sidebar] 페이지 이동:', menu.path)
      navigate(menu.path)
      if (window.innerWidth < 768) {
        onClose()
      }
    }
  }

  const MenuItem = ({ menu, level = 0 }) => {
    const Icon = iconMap[menu.icon] || MenuIcon
    const hasChildren = menu.children && menu.children.length > 0
    const isExpanded = expandedMenus[menu.id]

    return (
      <div>
        {menu.path ? (
          <NavLink
            to={menu.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-gray-700 hover:text-white transition-colors ${
                isActive ? 'bg-gray-700 text-white border-l-4 border-blue-500' : ''
              } ${level > 0 ? 'pl-8' : ''}`
            }
            onClick={() => hasChildren && toggleMenu(menu.id)}
          >
            <Icon size={20} />
            <span className="flex-1">{menu.name}</span>
            {hasChildren && (
              isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />
            )}
          </NavLink>
        ) : (
          <button
            onClick={() => handleMenuClick(menu)}
            className={`w-full flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-gray-700 hover:text-white transition-colors ${
              level > 0 ? 'pl-8' : ''
            }`}
          >
            <Icon size={20} />
            <span className="flex-1 text-left">{menu.name}</span>
            {hasChildren && (
              isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />
            )}
          </button>
        )}

        {hasChildren && isExpanded && (
          <div className="bg-gray-750">
            {menu.children.map(child => (
              <MenuItem key={child.id} menu={child} level={level + 1} />
            ))}
          </div>
        )}
      </div>
    )
  }

  console.log('🎨 [Sidebar] 렌더링:', { 
    loading, 
    menuCount: menus.length,
    menus: menus.map(m => m.name)
  })

  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed md:static inset-y-0 left-0 z-30 w-64 bg-gray-800 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* 헤더 */}
        <div className="flex items-center justify-between h-16 px-4 bg-gray-900 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">A</span>
            </div>
            <div>
              <h1 className="text-white font-bold text-lg">Admin Panel</h1>
              <p className="text-gray-400 text-xs">관리자 시스템</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="md:hidden text-gray-400 hover:text-white"
          >
            <X size={24} />
          </button>
        </div>

        {/* 메뉴 리스트 */}
        <nav className="flex-1 overflow-y-auto py-4 h-[calc(100vh-8rem)]">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-8 gap-2">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
              <p className="text-gray-400 text-sm">메뉴 로딩 중...</p>
            </div>
          ) : menus.length === 0 ? (
            <div className="px-4 py-8">
              <div className="bg-yellow-900 bg-opacity-20 border border-yellow-500 rounded-lg p-4">
                <p className="text-yellow-400 text-sm font-medium">메뉴가 없습니다</p>
                <p className="text-yellow-300 text-xs mt-1">
                  메뉴 관리에서 메뉴를 등록하세요
                </p>
              </div>
            </div>
          ) : (
            <div>
              {menus.map(menu => (
                <MenuItem key={menu.id} menu={menu} />
              ))}
            </div>
          )}
        </nav>

        {/* 푸터 */}
        <div className="border-t border-gray-700 p-4">
          <div className="flex items-center gap-3 text-gray-400 text-sm">
            <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center">
              <span className="text-white font-semibold">A</span>
            </div>
            <div className="flex-1">
              <p className="text-white font-medium">Admin</p>
              <p className="text-xs">admin@example.com</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  )
}

export default Sidebar
