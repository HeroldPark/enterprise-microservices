import { useQuery } from '@tanstack/react-query'
import { orderService } from '../services/orderService'
import { useAuthStore } from '../../app/authStore'
import OrderList from '../components/OrderList'
import { Loader } from 'lucide-react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { useEffect } from 'react'

const Orders = () => {
  const navigate = useNavigate()
  const { user, isAuthenticated } = useAuthStore()

  // 인증 체크 - 로그인하지 않은 경우 로그인 페이지로 리다이렉트
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login', { 
        state: { from: '/orders' },
        replace: true 
      })
    }
  }, [isAuthenticated, navigate])

  const { data: orders, isLoading, error } = useQuery({
    queryKey: ['orders', user?.id],
    queryFn: () => orderService.getOrderHistory(user.id),
    enabled: !!user?.id && isAuthenticated,
  })

  // 로그인하지 않은 경우 null 반환 (리다이렉트 중)
  if (!isAuthenticated) {
    return null
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-500">Error loading orders: {error.message}</p>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <motion.h1
        className="text-4xl font-bold text-gray-900 mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        My Orders
      </motion.h1>
      {orders && orders.length > 0 ? (
        <OrderList orders={orders} />
      ) : (
        <div className="text-center py-12">
          <p className="text-gray-500">No orders yet</p>
        </div>
      )}
    </div>
  )
}

export default Orders