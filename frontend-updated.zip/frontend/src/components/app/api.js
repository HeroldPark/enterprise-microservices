import axios from 'axios'

// const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080/api'
const API_BASE_URL = '/api'

const api = axios.create({
  baseURL: 'http://localhost:8080/api',  // Gateway 포트
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true,  // ⭐ 중요: CORS credentials
})

// Request interceptor to add token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`  // 토큰 추가
    }
    return config
  },
  (error) => Promise.reject(error)
)

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // 401 오류 시 로그인 페이지로 리다이렉트하지 않고 에러만 반환
    if (error.response?.status === 401) {
      // 토큰 제거
      localStorage.removeItem('token')

      // 로그인 페이지로 리다이렉트 대신 에러 반환
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api
