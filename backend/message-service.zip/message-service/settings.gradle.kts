rootProject.name = "message-service"
