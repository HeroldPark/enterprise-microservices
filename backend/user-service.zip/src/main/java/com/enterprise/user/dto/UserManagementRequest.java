package com.enterprise.user.dto;

import com.enterprise.user.entity.User;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserManagementRequest {

    @NotBlank(message = "Username is required")
    @Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
    private String username;

    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    private String email;

    // 비밀번호는 선택적 (수정 시 변경하지 않을 수 있음)
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;

    private String firstName;
    
    private String lastName;
    
    private String phoneNumber;
    
    private User.Role role;
    
    private Boolean enabled;
}
